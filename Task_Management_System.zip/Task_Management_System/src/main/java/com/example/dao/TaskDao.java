package com.example.dao;

import java.net.ConnectException;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import com.example.model.Task;

public class TaskDao {
	
	// JDBC connection parameters
    String jdbcUrl = "jdbc:mysql://localhost:3306/task_management_system?useSSL=false";
	String username = "root";
    String password = "12345";
    
    
    private static final String insert_task_query= "INSERT INTO task_management_table" +" (task_name, priority_task, date_of_task_completion) VALUES "+"(?, ?, ?)";
    private static final String delete_task_query= "DELETE FROM task_management_table WHERE task_name = ?";
    private static final String display_task_using_task_name="SELECT taskName, priority, deadline FROM task_management_table";
    private static final String UPDATE_USERS_SQL = "update task_management_table set task_name = ?,priority_task= ?, date_of_task_completion =? where task_name = ?;";
    

    void connect()
    {
    	try {    
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/task_management_system", "root", "12345");
        Statement smt= con.createStatement();
    }
    catch (Exception e)
    {
        System.out.println("Connection is not established successfully!");		}
    }
    
    
    public void insertTask(Task task)
    {
    try {    
        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/task_management_system", "root", "12345");
        Statement smt= con.createStatement();
        PreparedStatement preparedstatement= con.prepareStatement(insert_task_query);
        preparedstatement.setString(1, task.getTaskName());
        preparedstatement.setString(2, task.getPriority());
        preparedstatement.setString(3, task.getDeadline());
        preparedstatement.executeUpdate();
    }
    catch (Exception e)
    {
    	e.printStackTrace();
      	}
    }
    

	public Task selectTask(String task_name) {
		Task task= null;
		// Step 1: Establishing a Connection
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/task_management_system", "root", "12345");
		        Statement smt= con.createStatement();
				PreparedStatement preparedStatement = con.prepareStatement(display_task_using_task_name);) {
			preparedStatement.setString(1, task_name);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String t_name = rs.getString("task_name");
				String task_priority = rs.getString("priority_task");
				String deadline= rs.getString("date_of_task_completion");
				task = new Task(t_name, task_priority, deadline);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return task;
	}
    
	
	
	public List<Task> selectAllTask() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Task> tasks = new ArrayList<>();
		// Step 1: Establishing a Connection
		try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/task_management_system", "root", "12345");
		        Statement smt= con.createStatement();
				PreparedStatement preparedStatement = con.prepareStatement(display_task_using_task_name);) {
			
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String t_name = rs.getString("task_name");
				String task_priority = rs.getString("priority_task");
				String deadline= rs.getString("date_of_task_completion");
				tasks.add(new Task(t_name, task_priority, deadline));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return tasks;
	}
    
    
	
	
    public boolean deleteTask(String taskname) throws SQLException 
    {
    	boolean task_deleted=false;
    	try {
    		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/task_management_system", "root", "12345");
            PreparedStatement psmt = con.prepareStatement(delete_task_query);
            psmt.setString(1, taskname);
            
            task_deleted= psmt.executeUpdate() > 0;
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	return task_deleted;
    }
    
    public boolean updateTask(Task task) throws SQLException {
		boolean rowUpdated;
		try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/task_management_system", "root", "12345");
				PreparedStatement statement = connection.prepareStatement(UPDATE_USERS_SQL);) {
			statement.setString(1, task.getTaskName());
			statement.setString(2, task.getPriority());
			statement.setString(3, task.getDeadline());
		

			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}
}

package com.example.web;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import com.example.model.*;
import com.example.dao.*;

/**
 * Servlet implementation class TaskServlet
 */
@WebServlet("/")
public class TaskServlet extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	private TaskDao task_dao;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TaskServlet() {
    	this.task_dao= new TaskDao();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter(); 
		
		String action= request.getServletPath();
		
		switch(action)
		{
		case "/new":
			try {
				showNewForm(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
			
		case "/update":
			try {
				updateTask(request, response);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		case "/insert":
			try {
				insertTask(request, response);
			}
			catch(SQLException sqle)
			{
				sqle.printStackTrace();
			}
			break;
		case "/delete":
			try {
				deleteTask(request, response);
			}
			catch(SQLException sqle)
			{
				sqle.printStackTrace();
			}
			break;

		default:
			//handling TASK LIST SECTION
			try {
				taskList(request, response);
			}
			catch(SQLException sqle)
			{
				sqle.printStackTrace();
			}
			break;
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

	private void showNewForm(HttpServletRequest request , HttpServletResponse response) throws SQLException, IOException
	{
		RequestDispatcher dispatcher= request.getRequestDispatcher("task-form.jsp");
		try {
		dispatcher. forward(request,response);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private void insertTask(HttpServletRequest request, HttpServletResponse response) throws SQLException ,IOException
	{
		String task_name= request.getParameter("task_name");
		String priority= request.getParameter("task_priority");
		String deadline= request.getParameter("deadline");
		Task newTask= new Task(task_name,priority, deadline);
		task_dao.insertTask(newTask);
		response.sendRedirect("list");
	}
	
	
	private void deleteTask(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException
	{
		String task_name= request.getParameter("task_name");
		task_dao.deleteTask(task_name);
		response.sendRedirect("list");
	}
	
	
	private void taskList(HttpServletRequest request, HttpServletResponse response)throws SQLException, IOException 
	{
		List<Task> list_task= task_dao.selectAllTask();
		try {
		request.setAttribute("list_task", list_task);
		RequestDispatcher dispatcher = request.getRequestDispatcher("task-list.jsp");
		dispatcher.forward(request, response);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	
	private void updateTask(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		String task_name = request.getParameter("task_name");
		String task_priority = request.getParameter("task_priority");
		String deadline= request.getParameter("deadline");

		Task task= new Task(task_name, task_priority, deadline);
		task_dao.updateTask(task);
		response.sendRedirect("list");
	}
}
package com.example.model;

public class Task {
	 private String taskName;
	    private String priority;
	    private String deadline;

	    // Constructors, getters, and setters
	    public Task() {
	        // No-argument constructor code
	    }


	    public Task(String taskName, String priority, String deadline) {
	        this.taskName = taskName;
	        this.priority = priority;
	        this.deadline = deadline;
	    }

	    // Getters and setters for taskName, priority, and deadline
	 // Getters and setters for taskName
	    public String getTaskName() {
	        return taskName;
	    }

	    public void setTaskName(String taskName) {
	        this.taskName = taskName;
	    }

	    // Getters and setters for priority
	    public String getPriority() {
	        return priority;
	    }

	    public void setPriority(String priority) {
	        this.priority = priority;
	    }

	    // Getters and setters for deadline
	    public String getDeadline() {
	        return deadline;
	    }

	    public void setDeadline(String deadline) {
	        this.deadline = deadline;
	    }

	    // Override toString() method for a readable representation of the task
	    @Override
	    public String toString() {
	        return "Task{" +
	                "taskName='" + taskName + '\'' +
	                ", priority='" + priority + '\'' +
	                ", deadline='" + deadline + '\'' +
	                '}';
	  }
}
